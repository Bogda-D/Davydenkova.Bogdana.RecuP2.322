package model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import repository.Almacenable;
import repository.CSVConvertible;

public class Inventario<T extends CSVConvertible> implements Almacenable<T> {

    private List<T> elementos = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Item invalido");
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Iterator<T> iterator = elementos.iterator();
        while (iterator.hasNext()) {
            T e = iterator.next();
            if (criterio.test(e)) {
                iterator.remove();
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        if (elementos.isEmpty()) {
            System.out.println("No hay elementos");
        }
        return new ArrayList<>(elementos);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        T encontrado = null;
        for (T e : elementos) {
            if (criterio.test(e)) {
                encontrado = e;
            }
        }
        return encontrado;
    }

    @Override
    public void ordenar() {
        Collections.sort((List) elementos);
    }

    @Override
    public void ordenar(Comparator<T> cmp) {
        elementos.sort(cmp);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {//patovica
                toReturn.add(e);
            }
        }
        if (toReturn.isEmpty()) {
            System.out.println("No hay elementos");
        }
        return toReturn;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> toReturn = new ArrayList<>();
        for (T e : elementos) {
            toReturn.add(operador.apply(e));
        }
        return toReturn;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (T e : elementos) {
            if (criterio.test(e)) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(elementos);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        elementos.clear();

        try (ObjectInputStream deserealizador = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) deserealizador.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            writer.write(RobotMarte.toHeaderCSV());
            writer.newLine();

            for (T e : elementos) {
                writer.write(e.toCSV());
                writer.newLine();
            }

        } catch (IOException ex) {
            ex.getMessage();
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        elementos.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            String encabezado = RobotMarte.toHeaderCSV();
            reader.readLine();// lectura fantasma p/ saltear encabezado

            while ((linea = reader.readLine()) != null) {
                elementos.add((T) RobotMarte.fromCSV(linea));
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            writer.write(gson.toJson(elementos));
        }
    }

}
