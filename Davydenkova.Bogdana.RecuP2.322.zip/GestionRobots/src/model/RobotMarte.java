package model;

import java.io.Serializable;
import repository.CSVConvertible;
import service.ServiceClase;

public class RobotMarte implements Comparable<RobotMarte>, CSVConvertible {

    private static final long serialVersionUID = 1L;
    private final int id;
    private final String nombre;
    private final TipoRobot tipo;
    private final int nivelBateria;
    private final int MIN_NIVEL_BATERIA = 0;
    private final int MAX_NIVEL_BATERIA = 100;
    private final int anioFabricacion;
    private final double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = validarNivelBateria(nivelBateria);
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    private int validarNivelBateria(int nivel) {
        if (nivel < MIN_NIVEL_BATERIA || nivel > MAX_NIVEL_BATERIA) {
            throw new IndexOutOfBoundsException("Nivel de bateria fuera de rango");
        }
        return nivel;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public double getKmRecorridos() {
        return kmRecorridos;
    }

    @Override
    public int compareTo(RobotMarte o) {
        int cmp = Integer.compare(o.getNivelBateria(), this.nivelBateria);
        if (cmp == 0) {
            cmp = Double.compare(o.getKmRecorridos(), this.kmRecorridos);
        }
        return cmp;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + tipo + ","
                + nivelBateria + "," + anioFabricacion + "," + kmRecorridos;
    }

    public static String toHeaderCSV() {// encabezado de atributos
        return ServiceClase.getStringAtributos(RobotMarte.class);
    }

    public static RobotMarte fromCSV(String linea) {
        String[] atributos = linea.split(",");

        int id = Integer.parseInt(atributos[0]);
        String nombre = atributos[1];
        TipoRobot tipo = TipoRobot.valueOf(atributos[2]);// para pasar de String a Enum
        int nivelBateria = Integer.parseInt(atributos[3]);
        int anioFabricacion = Integer.parseInt(atributos[4]);
        double kmRecorridos = Double.parseDouble(atributos[5]);

        return new RobotMarte(id, nombre, tipo, nivelBateria, anioFabricacion, kmRecorridos);
    }

    @Override
    public String toString() {
        return "RobotMarte{" + "id=" + id + ", nombre=" + nombre + ", tipo=" + tipo + ", nivelBateria=" + nivelBateria + ", anioFabricacion=" + anioFabricacion + ", kmRecorridos=" + kmRecorridos + '}';
    }

}
