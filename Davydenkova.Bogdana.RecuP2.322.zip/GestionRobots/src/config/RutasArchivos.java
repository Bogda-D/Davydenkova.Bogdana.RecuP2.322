package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivos {
    
    static final String BASE = "src/resources/";
    static final String FILE_CSV = "robots.csv";
    static final String FILE_BIN = "robots.bin";
    static final String FILE_JSON = "robots.json";
    
    static Path getRutaCSV(){
        return Paths.get(BASE, FILE_CSV); //devuelve un Path obtenido de concatenacion de Strings
    }
    
    static Path getRutaBIN(){
        return Paths.get(BASE, FILE_BIN);
    }
    
    static Path getRutaJSON(){
        return Paths.get(BASE, FILE_JSON);
    }
    
    static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    static String getRutaBINString(){
        return getRutaBIN().toString();
    }
    
    static String getRutaJSONString(){
        return getRutaJSON().toString();
    }
}
