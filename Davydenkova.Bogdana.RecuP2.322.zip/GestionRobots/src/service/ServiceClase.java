package service;

import model.RobotMarte;


public interface ServiceClase {
    
    static String getStringAtributos(Class<?> clase){
        StringBuilder sb = new StringBuilder();

        if (clase.equals(RobotMarte.class)) {
            sb.append("id").append(",");
            sb.append("nombre").append(",");
            sb.append("tipo").append(",");
            sb.append("nivel bateria").append(",");
            sb.append("anio fabricacion").append(",");
            sb.append("km recorridos");
        }
        return sb.toString();
    }
}
