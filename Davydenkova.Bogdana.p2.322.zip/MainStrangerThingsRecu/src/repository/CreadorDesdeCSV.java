package repository;

@FunctionalInterface
public interface CreadorDesdeCSV<T> {
    T crear(String linea);
}
