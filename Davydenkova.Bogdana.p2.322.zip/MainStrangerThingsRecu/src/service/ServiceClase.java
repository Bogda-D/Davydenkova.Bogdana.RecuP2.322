package service;

//import model.Empleado;
import model.Criatura;

public interface ServiceClase {
    
    static String getStringAtributos(Class<?> clase){
        StringBuilder sb = new StringBuilder();

        if (clase.equals(Criatura.class)) {
            sb.append("id").append(",");
            sb.append("nombre").append(",");
            sb.append("origen").append(",");
            sb.append("tipo");
        }
        return sb.toString();
    }
}
