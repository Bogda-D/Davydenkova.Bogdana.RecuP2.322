package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;
import repository.CSVSerializable;
import repository.CreadorDesdeCSV;
//import repository.CSVSerializable;
//import repository.CreadorDesdeCSV;

public class BestiarioUpsideDown<T extends CSVSerializable> {

    private List<T> elementos = new ArrayList<>();

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    public void agregar(T item) {
        Objects.requireNonNull(item, "Item invalido");
        elementos.add(item);
    }

    public boolean contiene(T item) {
        return elementos.contains(item);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        elementos.remove(indice);
    }

    private int tamanio() {
        return elementos.size();
    }

    public void paraCadaElemento(Consumer<T> accion) {
        if(elementos.isEmpty()){
            System.out.println("No hay criaturas");
        }
        for (T e : elementos) {
            accion.accept(e);
        }
    }

    public List<T> filtrar(Predicate<T> filtro) {
        List<T> toReturn = new ArrayList<>();
        for (T e : elementos) {
            if (filtro.test(e)) {//patovica
                toReturn.add(e);
            }
        }
        if(toReturn.isEmpty()){
            System.out.println("No hay criaturas");
        }
        return toReturn;
    }

    public void ordenar(Comparator<? super T> criterio) {
        elementos.sort(criterio);
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(elementos);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        elementos.clear();

        try (ObjectInputStream deserealizador = new ObjectInputStream(new FileInputStream(path))) {
            elementos = (List<T>) deserealizador.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write(Criatura.toHeaderCSV());
            writer.newLine();

            for (T e : elementos) {
                writer.write(e.toCSV());
                writer.newLine();
            }

        } catch (IOException ex) {
            ex.getMessage();
        }
    }

    public void cargarDesdeCSV(String path, CreadorDesdeCSV<T> creador) throws IOException {
        elementos.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String linea;
            String encabezado = Criatura.toHeaderCSV();
            reader.readLine();// lectura fantasma p/ saltear encabezado

            while ((linea = reader.readLine()) != null) {
                elementos.add((T) Criatura.fromCSV(linea));
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
    }
}
