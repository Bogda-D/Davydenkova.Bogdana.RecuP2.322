package model;

import java.util.Objects;
import repository.CSVSerializable;
import service.ServiceClase;

public class Criatura implements Comparable<Criatura>, CSVSerializable{

    private static final long serialVersionUID = 1L;
    private final int id;
    private final String nombre;
    private final String origen;
    private final TipoCriatura tipo;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipo) {
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipo = tipo;
    }
    
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Criatura{" + "id=" + id + ", nombre=" + nombre + ", origen=" + origen + ", tipo=" + tipo + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Criatura p)) {
            return false;
        } else {
            return this.id == p.id;
        }
    }
    
    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(id, o.id);
    }

    public String toCSV(){
        return id + "," + nombre + "," + origen + "," + tipo;
    }
    
    public static Criatura fromCSV(String linea){
        String[] atributos = linea.split(",");
        
        int id = Integer.parseInt(atributos[0]);
        String nombre = atributos[1];
        String origen = atributos[2];
        TipoCriatura tipo = TipoCriatura.valueOf(atributos[3]);// para pasar de String a Enum
        
        return new Criatura(id, nombre, origen, tipo);
    }
    
    public static String toHeaderCSV(){// encabezado de atributos
        return ServiceClase.getStringAtributos(Criatura.class);
    }
}
